const STORAGE_KEY = "fleetCalculatorState";
const MAX_HISTORY = 10;

const state = {
  expression: "",
  result: "0",
  history: [],
  activeTab: "calc"
};

const expressionEl = document.getElementById("expression");
const resultEl = document.getElementById("result");
const historyListEl = document.getElementById("historyList");
const copyBtnEl = document.getElementById("copyBtn");
const clearHistoryBtnEl = document.getElementById("clearHistoryBtn");
const tabs = Array.from(document.querySelectorAll(".tab"));
const panels = {
  calc: document.getElementById("tab-calc"),
  history: document.getElementById("tab-history")
};

function saveState() {
  chrome.storage.local.set({ [STORAGE_KEY]: state });
}

function loadState() {
  chrome.storage.local.get(STORAGE_KEY, (data) => {
    if (chrome.runtime.lastError) {
      render();
      return;
    }
    const saved = data[STORAGE_KEY];
    if (saved && typeof saved === "object") {
      state.expression = saved.expression || "";
      state.result = saved.result || "0";
      state.history = Array.isArray(saved.history) ? saved.history.slice(0, MAX_HISTORY) : [];
      state.activeTab = saved.activeTab === "history" ? "history" : "calc";
    }
    render();
  });
}

function tokenizeExpression(expr) {
  const tokens = [];
  let i = 0;
  let prevType = "operator";

  while (i < expr.length) {
    const ch = expr[i];
    if (ch === " ") {
      i += 1;
      continue;
    }

    if (/[0-9.]/.test(ch)) {
      if (prevType === "number") {
        tokens.push({ type: "operator", value: "*" });
      }
      let number = "";
      let dotCount = 0;
      while (i < expr.length && /[0-9.]/.test(expr[i])) {
        if (expr[i] === ".") {
          dotCount += 1;
          if (dotCount > 1) {
            throw new Error("Invalid number format");
          }
        }
        number += expr[i];
        i += 1;
      }
      if (number === ".") {
        throw new Error("Invalid number");
      }
      tokens.push({ type: "number", value: Number(number) });
      prevType = "number";
      continue;
    }

    if (ch === "(") {
      if (prevType === "number") {
        tokens.push({ type: "operator", value: "*" });
      }
      tokens.push({ type: "paren", value: ch });
      prevType = "operator";
      i += 1;
      continue;
    }

    if (ch === ")") {
      tokens.push({ type: "paren", value: ch });
      prevType = "number";
      i += 1;
      continue;
    }

    if ("+-*/".includes(ch)) {
      if (ch === "-" && prevType !== "number") {
        tokens.push({ type: "number", value: 0 });
      }
      tokens.push({ type: "operator", value: ch });
      prevType = "operator";
      i += 1;
      continue;
    }

    if (ch === "%") {
      if (prevType !== "number") {
        throw new Error("Malformed expression");
      }
      tokens.push({ type: "percent", value: ch });
      prevType = "number";
      i += 1;
      continue;
    }

    throw new Error("Invalid character");
  }

  return tokens;
}

function evaluateTokens(tokens) {
  const values = [];
  const ops = [];
  const precedence = { "+": 1, "-": 1, "*": 2, "/": 2 };

  function applyOp() {
    const op = ops.pop();
    const b = values.pop();
    const a = values.pop();
    if (a === undefined || b === undefined || !op) {
      throw new Error("Malformed expression");
    }
    if (op === "+") values.push(a + b);
    else if (op === "-") values.push(a - b);
    else if (op === "*") values.push(a * b);
    else if (op === "/") values.push(a / b);
  }

  for (const token of tokens) {
    if (token.type === "number") {
      values.push(token.value);
      continue;
    }

    if (token.type === "paren" && token.value === "(") {
      ops.push(token.value);
      continue;
    }

    if (token.type === "paren" && token.value === ")") {
      while (ops.length && ops[ops.length - 1] !== "(") {
        applyOp();
      }
      if (ops.pop() !== "(") {
        throw new Error("Mismatched parentheses");
      }
      continue;
    }

    if (token.type === "operator") {
      while (
        ops.length &&
        ops[ops.length - 1] !== "(" &&
        precedence[ops[ops.length - 1]] >= precedence[token.value]
      ) {
        applyOp();
      }
      ops.push(token.value);
      continue;
    }

    if (token.type === "percent") {
      const current = values.pop();
      if (current === undefined) {
        throw new Error("Malformed expression");
      }
      if (ops.length && ["+", "-"].includes(ops[ops.length - 1]) && values.length > 0) {
        const base = values[values.length - 1];
        values.push((base * current) / 100);
      } else {
        values.push(current / 100);
      }
    }
  }

  while (ops.length) {
    if (ops[ops.length - 1] === "(") {
      throw new Error("Mismatched parentheses");
    }
    applyOp();
  }

  if (values.length !== 1) {
    throw new Error("Malformed expression");
  }
  return values[0];
}

function safeEval(expr) {
  if (!expr) {
    return "0";
  }
  if (!/^[0-9+\-*/().%\s]+$/.test(expr)) {
    return "Помилка";
  }

  try {
    const tokens = tokenizeExpression(expr);
    const value = evaluateTokens(tokens);
    if (typeof value !== "number" || Number.isNaN(value) || !Number.isFinite(value)) {
      return "Помилка";
    }
    return Number(value.toFixed(10)).toString();
  } catch {
    return "Помилка";
  }
}

function getLiveResult(expr, fallbackResult) {
  if (!expr) {
    return "0";
  }
  const trimmed = expr.trim();
  if (!trimmed) {
    return "0";
  }
  if (/[+\-*/.(]$/.test(trimmed)) {
    const withoutTail = trimmed.replace(/[+\-*/.(\s]+$/, "");
    if (!withoutTail) {
      return fallbackResult ?? "0";
    }
    const partial = safeEval(withoutTail);
    return partial === "Помилка" ? fallbackResult ?? "0" : partial;
  }
  const evaluated = safeEval(trimmed);
  return evaluated === "Помилка" ? fallbackResult ?? "0" : evaluated;
}

function renderHistory() {
  historyListEl.innerHTML = "";
  if (!state.history.length) {
    const empty = document.createElement("li");
    empty.className = "history-empty";
    empty.textContent = "Історія порожня";
    historyListEl.appendChild(empty);
    return;
  }

  state.history.forEach((item) => {
    const li = document.createElement("li");
    li.className = "history-item";

    const exp = document.createElement("div");
    exp.className = "history-expression";
    exp.textContent = `${item.expression} =`;

    const res = document.createElement("div");
    res.className = "history-result";
    const resultValue = document.createElement("span");
    resultValue.className = "history-result-value";
    resultValue.textContent = formatForDisplay(item.result);

    const copyButton = document.createElement("button");
    copyButton.className = "history-copy-btn";
    copyButton.type = "button";
    copyButton.dataset.copyResult = item.result;
    copyButton.textContent = "⧉";
    copyButton.title = "Копіювати результат";

    res.append(resultValue, copyButton);
    li.append(exp, res);
    historyListEl.appendChild(li);
  });
}

function setTab(tabName) {
  state.activeTab = tabName;
  tabs.forEach((tab) => tab.classList.toggle("is-active", tab.dataset.tab === tabName));
  Object.entries(panels).forEach(([name, panel]) => {
    panel.classList.toggle("is-active", name === tabName);
  });
  saveState();
}

function render() {
  expressionEl.textContent = state.expression || "0";
  resultEl.textContent = formatForDisplay(state.result || "0");
  renderHistory();
  setTab(state.activeTab);
}

function formatForDisplay(value) {
  if (!value || value === "Помилка") {
    return value || "0";
  }
  const raw = String(value);
  if (!/^-?\d+(\.\d+)?$/.test(raw)) {
    return raw;
  }
  const [intPart, decPart] = raw.split(".");
  const sign = intPart.startsWith("-") ? "-" : "";
  const absInt = sign ? intPart.slice(1) : intPart;
  const grouped = absInt.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return decPart ? `${sign}${grouped}.${decPart}` : `${sign}${grouped}`;
}

function appendValue(rawValue) {
  const value = rawValue === "×" ? "*" : rawValue === "÷" ? "/" : rawValue;
  state.expression += value;
  state.result = getLiveResult(state.expression, state.result);
  render();
  saveState();
}

function clearAll() {
  state.expression = "";
  state.result = "0";
  render();
  saveState();
}

function backspace() {
  if (!state.expression) {
    return;
  }
  state.expression = state.expression.slice(0, -1);
  state.result = getLiveResult(state.expression, "0");
  render();
  saveState();
}

function applyEquals() {
  if (!state.expression) {
    return;
  }
  const computed = safeEval(state.expression);
  if (computed === "Помилка") {
    state.result = computed;
    render();
    saveState();
    return;
  }
  state.history.unshift({
    expression: state.expression,
    result: computed
  });
  state.history = state.history.slice(0, MAX_HISTORY);
  state.expression = computed;
  state.result = computed;
  render();
  saveState();
}

function appendFromText(text) {
  const cleaned = (text || "").replace(/,/g, ".").replace(/[^\d+\-*/().%\s]/g, "").trim();
  if (!cleaned) {
    return;
  }
  state.expression += cleaned;
  state.result = getLiveResult(state.expression, state.result);
  render();
  saveState();
}

async function pasteFromClipboard() {
  try {
    const text = await navigator.clipboard.readText();
    appendFromText(text);
  } catch {
    // Browser may block clipboard read if gesture/permission fails.
  }
}

async function copyResult() {
  const valueToCopy = state.result || "0";
  try {
    await navigator.clipboard.writeText(valueToCopy);
    copyBtnEl.classList.add("is-copied");
    copyBtnEl.textContent = "✓";
    setTimeout(() => {
      copyBtnEl.classList.remove("is-copied");
      copyBtnEl.textContent = "⧉";
    }, 900);
  } catch {
    // Clipboard write may fail if permission/gesture is blocked.
  }
}

async function copyFromHistory(button, resultValue) {
  try {
    await navigator.clipboard.writeText(resultValue);
    button.classList.add("is-copied");
    button.textContent = "✓";
    setTimeout(() => {
      button.classList.remove("is-copied");
      button.textContent = "⧉";
    }, 900);
  } catch {
    // Clipboard write may fail if permission/gesture is blocked.
  }
}

document.getElementById("keypad").addEventListener("click", (event) => {
  const target = event.target;
  if (!(target instanceof HTMLButtonElement)) {
    return;
  }
  const value = target.dataset.value;
  if (!value) {
    return;
  }
  appendValue(value);
});

document.getElementById("clearBtn").addEventListener("click", clearAll);
document.getElementById("clearKeyBtn").addEventListener("click", clearAll);
document.getElementById("backspaceBtn").addEventListener("click", backspace);
document.getElementById("equalsBtn").addEventListener("click", applyEquals);
document.getElementById("pasteBtn").addEventListener("click", pasteFromClipboard);
copyBtnEl.addEventListener("click", copyResult);
clearHistoryBtnEl.addEventListener("click", () => {
  state.history = [];
  render();
  saveState();
});

historyListEl.addEventListener("click", (event) => {
  const target = event.target;
  if (!(target instanceof HTMLButtonElement)) {
    return;
  }
  const resultValue = target.dataset.copyResult;
  if (!resultValue) {
    return;
  }
  copyFromHistory(target, resultValue);
});

tabs.forEach((tab) => {
  tab.addEventListener("click", () => setTab(tab.dataset.tab));
});

document.addEventListener("keydown", (event) => {
  const { key, ctrlKey, metaKey } = event;

  if ((ctrlKey || metaKey) && key.toLowerCase() === "v") {
    return;
  }

  if (/^[0-9]$/.test(key) || ["+", "-", "*", "/", ".", "(", ")", "%"].includes(key)) {
    appendValue(key);
    return;
  }
  if (key === "Backspace") {
    backspace();
    return;
  }
  if (key === "Enter" || key === "=") {
    applyEquals();
    return;
  }
  if (key === "Escape") {
    clearAll();
  }
});

document.addEventListener("paste", (event) => {
  const text = event.clipboardData?.getData("text");
  if (text) {
    event.preventDefault();
    appendFromText(text);
  }
});

loadState();
