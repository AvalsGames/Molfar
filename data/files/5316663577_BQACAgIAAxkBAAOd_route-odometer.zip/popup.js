// ── State data (truck speed limits, mph) ─────────────────────────────────────
const STATES = {
  AL:{n:"Alabama",s:67},        AK:{n:"Alaska",s:65},
  AZ:{n:"Arizona",s:68},        AR:{n:"Arkansas",s:65},
  CA:{n:"California",s:55},     CO:{n:"Colorado",s:67},
  CT:{n:"Connecticut",s:60},    DE:{n:"Delaware",s:60},
  DC:{n:"Dist. of Columbia",s:65}, FL:{n:"Florida",s:68},
  GA:{n:"Georgia",s:64},        HI:{n:"Hawaii",s:60},
  ID:{n:"Idaho",s:68},          IL:{n:"Illinois",s:65},
  IN:{n:"Indiana",s:60},        IA:{n:"Iowa",s:64},
  KS:{n:"Kansas",s:70},         KY:{n:"Kentucky",s:65},
  LA:{n:"Louisiana",s:70},      ME:{n:"Maine",s:60},
  MD:{n:"Maryland",s:65},       MA:{n:"Massachusetts",s:60},
  MI:{n:"Michigan",s:60},       MN:{n:"Minnesota",s:65},
  MS:{n:"Mississippi",s:70},    MO:{n:"Missouri",s:65},
  MT:{n:"Montana",s:67},        NE:{n:"Nebraska",s:68},
  NV:{n:"Nevada",s:70},         NH:{n:"New Hampshire",s:60},
  NJ:{n:"New Jersey",s:60},     NM:{n:"New Mexico",s:70},
  NY:{n:"New York",s:60},       NC:{n:"North Carolina",s:65},
  ND:{n:"North Dakota",s:70},   OH:{n:"Ohio",s:68},
  OK:{n:"Oklahoma",s:70},       OR:{n:"Oregon",s:62},
  PA:{n:"Pennsylvania",s:65},   RI:{n:"Rhode Island",s:60},
  SC:{n:"South Carolina",s:65}, SD:{n:"South Dakota",s:70},
  TN:{n:"Tennessee",s:70},      TX:{n:"Texas",s:70},
  UT:{n:"Utah",s:70},           VT:{n:"Vermont",s:60},
  VA:{n:"Virginia",s:65},       WA:{n:"Washington",s:60},
  WV:{n:"West Virginia",s:67},  WI:{n:"Wisconsin",s:70},
  WY:{n:"Wyoming",s:70},
};
const ALL_CODES = Object.keys(STATES).sort();

// ── Storage ───────────────────────────────────────────────────────────────────
const sGet = k   => new Promise(r => chrome.storage.local.get(k, r));
const sSet = obj => new Promise(r => chrome.storage.local.set(obj, r));
const getPoints = async () => (await sGet("routePoints")).routePoints || [];
const setPoints = pts => sSet({ routePoints: pts });
const getOdo    = async () => (await sGet("odoValues")).odoValues || {};
const setOdo    = v   => sSet({ odoValues: v });
const getDebug  = async () => !!(await sGet("roDebug")).roDebug;
const setDebug  = v   => sSet({ roDebug: !!v });

const DEFAULT_DRIVER_SHEET_URL =
  "https://docs.google.com/spreadsheets/d/1IzaVY4d5O8Zultua-7W41q3Xdngy2iW-3xgy67TKNvU/edit?gid=723311401#gid=723311401";
const getDriverSheetUrlStored = async () => (await sGet("driverSheetUrl")).driverSheetUrl;
const setDriverSheetUrlStored = v => sSet({ driverSheetUrl: typeof v === "string" ? v : "" });
const getShowManualFields = async () => (await sGet("roShowManualFields")).roShowManualFields !== false;
const setShowManualFields = v => sSet({ roShowManualFields: !!v });

// ── Messenger links DB (for colleagues) ──────────────────────────────────
const DRIVER_LINKS_DB_KEY = "driverLinksDb";
const normalizeUrl = (input) => {
  const raw = (input || "").toString().trim();
  if (!raw) return "";
  // If user pastes e.g. "t.me/..." or "example.com/..." -> add https://
  if (!/^https?:\/\//i.test(raw)) {
    return "https://" + raw.replace(/^\/+/, "");
  }
  // Prefer https://
  return raw.replace(/^http:\/\//i, "https://");
};
const getLinksDb = async () => (await sGet(DRIVER_LINKS_DB_KEY))[DRIVER_LINKS_DB_KEY] || {};
const setLinksDb = async (db) => sSet({ [DRIVER_LINKS_DB_KEY]: db });

function mergeLinksDb(baseDb, incoming) {
  const out = { ...(baseDb || {}) };
  if (!incoming || typeof incoming !== "object") return out;
  for (const site of Object.keys(incoming)) {
    const siteObj = incoming[site];
    if (!siteObj || typeof siteObj !== "object") continue;
    out[site] = out[site] || {};
    for (const id of Object.keys(siteObj)) {
      const url = normalizeUrl(siteObj[id]);
      if (!url) continue;
      out[site][id] = url;
    }
  }
  return out;
}

function applyManualFieldsVisibility(show) {
  const routeBlk = document.getElementById("routeManualBlock");
  const odoBlk = document.getElementById("odoManualBlock");
  if (routeBlk) routeBlk.classList.toggle("ro-manual-hidden", !show);
  if (odoBlk) odoBlk.classList.toggle("ro-manual-hidden", !show);
}

// ── Point format helpers ──────────────────────────────────────────────────────
// Points are stored as "Display label" or "Display label||lat,lng"
function ptLabel(p)  { return p.split("||")[0]; }
function ptQuery(p)  {
  const parts = p.split("||");
  // Use coords if present (more accurate); else use label text
  return parts[1] ? parts[1] : parts[0];
}
function ptHasCoords(p) { return p.includes("||"); }

// ── Helpers ───────────────────────────────────────────────────────────────────
const pad2    = n  => String(Math.floor(Math.abs(n))).padStart(2, "0");
const toHHMM  = h  => `${pad2(h)}:${pad2((h - Math.floor(h)) * 60)}`;
const spdLabel = k => k === "CA" ? "55–58" : String(STATES[k].s);

function buildMapsUrl(pts) {
  if (pts.length < 2) return null;
  return "https://www.google.com/maps/dir/" +
    pts.map(p => encodeURIComponent(ptQuery(p))).join("/") +
    "?hl=en&travelmode=driving&data=!3m1!4b1!4m2!4m1!3e0";
}

// ── Combobox factory ──────────────────────────────────────────────────────────
function makeCombo(inputId, dropId, onSelect) {
  const inp  = document.getElementById(inputId);
  const drop = document.getElementById(dropId);
  let chosen = null, hiIdx = -1, query = "";

  function filter(q) {
    const u = q.trim().toUpperCase();
    return u ? ALL_CODES.filter(k =>
      k.startsWith(u) || STATES[k].n.toUpperCase().includes(u)
    ) : ALL_CODES;
  }

  function render(q) {
    query = q;
    const items = filter(q);
    hiIdx = items.length ? 0 : -1;
    drop.innerHTML = "";
    if (!items.length) {
      drop.innerHTML = `<div class="c-none">Нічого не знайдено</div>`;
    } else {
      items.forEach((k, i) => {
        const el = document.createElement("div");
        el.className = "c-opt" + (i === 0 ? " hi" : "");
        el.dataset.k = k;
        el.innerHTML = `<span class="c-code">${k}</span>
          <span class="c-name">${STATES[k].n}</span>
          <span class="c-spd">${spdLabel(k)} mph</span>`;
        el.addEventListener("mousedown", e => { e.preventDefault(); pick(k); });
        drop.appendChild(el);
      });
    }
    drop.classList.add("open");
  }

  function pick(k) {
    chosen = k;
    inp.value = `${k} — ${STATES[k].n}`;
    drop.classList.remove("open");
    onSelect(k);
  }

  inp.addEventListener("focus", () => {
    if (chosen) inp.value = "";
    render(chosen ? "" : inp.value);
  });
  inp.addEventListener("input", () => {
    chosen = null;
    onSelect(null);
    render(inp.value);
  });
  inp.addEventListener("blur", () => {
    setTimeout(() => {
      drop.classList.remove("open");
      if (chosen) inp.value = `${chosen} — ${STATES[chosen].n}`;
      else if (inp.value) inp.value = "";
    }, 160);
  });
  inp.addEventListener("keydown", e => {
    const items = filter(query);
    if (e.key === "ArrowDown") {
      e.preventDefault(); hiIdx = Math.min(hiIdx + 1, items.length - 1); hilite(hiIdx);
    } else if (e.key === "ArrowUp") {
      e.preventDefault(); hiIdx = Math.max(hiIdx - 1, 0); hilite(hiIdx);
    } else if (e.key === "Enter" && items[hiIdx]) {
      e.preventDefault(); pick(items[hiIdx]);
    } else if (e.key === "Escape") {
      drop.classList.remove("open"); inp.blur();
    }
  });

  function hilite(idx) {
    drop.querySelectorAll(".c-opt").forEach((el, i) => {
      el.classList.toggle("hi", i === idx);
      if (i === idx) el.scrollIntoView({ block: "nearest" });
    });
  }

  return {
    restore(k) {
      if (!k || !STATES[k]) return;
      chosen = k;
      inp.value = `${k} — ${STATES[k].n}`;
    },
    get value() { return chosen; },
    clear() { chosen = null; inp.value = ""; },
  };
}

// ── State card ────────────────────────────────────────────────────────────────
function renderCard(id, k) {
  const el = document.getElementById(id);
  if (!k || !STATES[k]) {
    el.classList.remove("filled");
    el.innerHTML = `<div class="s-empty">${id === "sc2" ? "Необов'язково" : "Не обрано"}</div>`;
    return;
  }
  el.classList.add("filled");
  el.innerHTML = `
    <div class="s-abbr">${k}</div>
    <div class="s-name">${STATES[k].n}</div>
    <div class="s-spd"><b>${spdLabel(k)}</b> mph</div>`;
}

// ── Odometer calculation ──────────────────────────────────────────────────────
function recalc(s1k, s2k) {
  const box = document.getElementById("resBox");
  const v1  = document.getElementById("od1").value;
  const v2  = document.getElementById("od2").value;
  const od1 = v1 !== "" ? parseFloat(v1) : 0;
  const od2 = v2 !== "" ? parseFloat(v2) : 0;
  const bothEmpty = v1 === "" && v2 === "";

  if (bothEmpty || !s1k) {
    box.innerHTML = `<div class="res-empty">Введіть показник одометра і виберіть штат</div>`;
    return;
  }
  const dist = Math.abs(od2 - od1);
  if (dist === 0) {
    box.innerHTML = `<div class="res-warn">Різниця одометрів дорівнює нулю</div>`;
    return;
  }
  const spd1 = STATES[s1k].s;
  const spd2 = s2k ? STATES[s2k].s : spd1;
  const avg  = (spd1 + spd2) / 2;
  const hrs  = dist / avg;
  const note = s2k
    ? `${s1k} (${spd1}) + ${s2k} (${spd2}) = середня <b>${avg.toFixed(1)} mph</b>`
    : `Один штат: <b>${spd1} mph</b>`;
  const partial = v1 === "" || v2 === ""
    ? `<div class="res-partial">OD ${v1 === "" ? "1" : "2"} не вказано — використано 0</div>`
    : "";

  box.innerHTML = `
    ${partial}
    <div class="res-dist-lbl">Відстань</div>
    <div class="res-dist"><span>${dist.toFixed(0)}</span> миль</div>
    <div class="res-time-lbl">Час у дорозі</div>
    <div class="res-time">${toHHMM(hrs)}</div>
    <div class="res-meta">${note}</div>`;
}

// ── Route rendering ───────────────────────────────────────────────────────────
function renderPoints(pts) {
  const list = document.getElementById("ptList");
  const lbl  = document.getElementById("listLbl");
  const open = document.getElementById("openBtn");
  const clr  = document.getElementById("clrBtn");

  list.innerHTML = "";
  lbl.textContent = pts.length ? `Точки маршруту (${pts.length})` : "Точки маршруту";

  if (!pts.length) {
    list.innerHTML = `
      <div class="empty-box">
        Точок ще немає.<br>
        Натисніть кнопку <strong>+</strong> біля адреси на сайті.
      </div>`;
  } else {
    pts.forEach((p, i) => {
      const cls    = i === 0 ? "p-start" : i === pts.length - 1 ? "p-end" : "p-mid";
      const role   = i === 0 ? "Початок" : i === pts.length - 1 ? "Кінець" : `Зупинка ${i}`;
      const label  = ptLabel(p);
      const coords = ptHasCoords(p) ? p.split("||")[1] : "";
      const el     = document.createElement("div");
      el.className = `point-card ${cls}`;
      el.innerHTML = `
        <div class="p-num">${i + 1}</div>
        <div class="p-info">
          <div class="p-addr" title="${label}">${label}</div>
          <div class="p-role">${role}${coords ? ` · <span style="font-family:monospace;color:#5b78ff">${coords}</span>` : ""}</div>
        </div>
        <button class="p-del" data-i="${i}" title="Видалити">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
            <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59
                     6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
          </svg>
        </button>`;
      list.appendChild(el);
    });
  }
  open.disabled = pts.length < 2;
  clr.disabled  = pts.length === 0;
}

async function tryClipboard() {
  try {
    const t = await navigator.clipboard.readText();
    if (t?.trim()) {
      const inp = document.getElementById("ptInput");
      inp.value = t.trim();
      inp.select();
    }
  } catch (_) {}
}

// ── INIT ──────────────────────────────────────────────────────────────────────
(async () => {
  const pts = await getPoints();
  renderPoints(pts);
  await tryClipboard();

  const ptInput = document.getElementById("ptInput");

  async function doAdd() {
    const v = ptInput.value.trim();
    if (!v) return;
    const arr = await getPoints();
    arr.push(v);
    await setPoints(arr);
    renderPoints(arr);
    ptInput.value = "";
    await tryClipboard();
    ptInput.focus();
  }

  document.getElementById("addBtn").addEventListener("click", doAdd);
  ptInput.addEventListener("keydown", e => { if (e.key === "Enter") doAdd(); });

  document.getElementById("ptList").addEventListener("click", async e => {
    const btn = e.target.closest(".p-del");
    if (!btn) return;
    const arr = await getPoints();
    arr.splice(+btn.dataset.i, 1);
    await setPoints(arr);
    renderPoints(arr);
  });

  document.getElementById("openBtn").addEventListener("click", async () => {
    const url = buildMapsUrl(await getPoints());
    if (url) chrome.tabs.create({ url });
  });

  document.getElementById("clrBtn").addEventListener("click", async () => {
    await setPoints([]);
    renderPoints([]);
    ptInput.value = "";
    await tryClipboard();
  });

  // ── Settings panel ─────────────────────────────────
  const settingsPanel = document.getElementById("settingsPanel");
  const settingsBtn = document.getElementById("settingsBtn");
  const sheetUrlInput = document.getElementById("sheetUrlInput");
  sheetUrlInput.placeholder = DEFAULT_DRIVER_SHEET_URL;
  const storedSheet = await getDriverSheetUrlStored();
  sheetUrlInput.value = (storedSheet && String(storedSheet).trim()) ? String(storedSheet).trim() : "";

  settingsBtn.addEventListener("click", () => {
    const open = settingsPanel.classList.toggle("open");
    settingsBtn.setAttribute("aria-expanded", open ? "true" : "false");
  });

  let sheetSaveTimer = null;
  const persistSheetUrl = () => setDriverSheetUrlStored(sheetUrlInput.value.trim());
  sheetUrlInput.addEventListener("input", () => {
    clearTimeout(sheetSaveTimer);
    sheetSaveTimer = setTimeout(persistSheetUrl, 400);
  });
  sheetUrlInput.addEventListener("blur", () => {
    clearTimeout(sheetSaveTimer);
    persistSheetUrl();
  });

  const dbgToggle = document.getElementById("dbgToggle");
  dbgToggle.checked = await getDebug();
  dbgToggle.addEventListener("change", async () => {
    await setDebug(dbgToggle.checked);
  });

  const manualFieldsToggle = document.getElementById("manualFieldsToggle");
  const showManual = await getShowManualFields();
  manualFieldsToggle.checked = showManual;
  applyManualFieldsVisibility(showManual);
  manualFieldsToggle.addEventListener("change", async () => {
    const on = manualFieldsToggle.checked;
    await setShowManualFields(on);
    applyManualFieldsVisibility(on);
  });

  if (showManual) ptInput.focus();

  // ── Import / Export links DB ────────────────────────────────────────
  const exportDbBtn = document.getElementById("exportDbBtn");
  const importDbBtn = document.getElementById("importDbBtn");
  const importDbFile = document.getElementById("importDbFile");
  const dbStatus = document.getElementById("dbStatus");

  function setDbStatus(text) {
    if (!dbStatus) return;
    dbStatus.textContent = text;
  }

  function downloadJsonFile(filename, obj) {
    const json = JSON.stringify(obj, null, 2);
    const blob = new Blob([json], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 800);
  }

  exportDbBtn.addEventListener("click", async () => {
    const db = await getLinksDb();
    downloadJsonFile("drivers-links.json", db);
    setDbStatus("Експорт виконано.");
  });

  importDbBtn.addEventListener("click", () => {
    importDbFile.value = "";
    importDbFile.click();
  });

  importDbFile.addEventListener("change", async () => {
    const file = importDbFile.files?.[0];
    if (!file) return;
    try {
      setDbStatus("Імпорт…");
      const text = await file.text();
      const parsed = JSON.parse(text);

      const current = await getLinksDb();
      const merged = mergeLinksDb(current, parsed);
      await setLinksDb(merged);

      setDbStatus("Імпорт завершено (merge).");
      // Нічого в UI не треба оновлювати, але future кнопки використають storage.
    } catch (e) {
      setDbStatus("Помилка імпорту. Перевір файл JSON.");
    }
  });

  // ── Odometer ───────────────────────────────────────
  let s1 = null, s2 = null;

  const persist = () => setOdo({
    od1: document.getElementById("od1").value,
    od2: document.getElementById("od2").value,
    s1: s1 || "", s2: s2 || "",
  });

  const combo1 = makeCombo("s1in", "s1drop", k => {
    s1 = k; renderCard("sc1", k); recalc(s1, s2); persist();
  });
  const combo2 = makeCombo("s2in", "s2drop", k => {
    s2 = k; renderCard("sc2", k); recalc(s1, s2); persist();
  });

  ["od1","od2"].forEach(id =>
    document.getElementById(id).addEventListener("input", () => {
      recalc(s1, s2); persist();
    })
  );

  document.getElementById("clrOdo").addEventListener("click", async () => {
    document.getElementById("od1").value = "";
    document.getElementById("od2").value = "";
    s1 = null; s2 = null;
    combo1.clear(); combo2.clear();
    renderCard("sc1", null); renderCard("sc2", null);
    document.getElementById("resBox").innerHTML =
      `<div class="res-empty">Введіть показники одометра і виберіть штат</div>`;
    await setOdo({});
  });

  const saved = await getOdo();
  if (saved.od1) document.getElementById("od1").value = saved.od1;
  if (saved.od2) document.getElementById("od2").value = saved.od2;
  if (saved.s1) { s1 = saved.s1; combo1.restore(saved.s1); renderCard("sc1", saved.s1); }
  if (saved.s2) { s2 = saved.s2; combo2.restore(saved.s2); renderCard("sc2", saved.s2); }
  recalc(s1, s2);
})();
