function updateBadge(count) {
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : "" });
  if (count > 0) chrome.action.setBadgeBackgroundColor({ color: "#5b78ff" });
}

chrome.storage.onChanged.addListener((changes) => {
  if (changes.routePoints) updateBadge((changes.routePoints.newValue || []).length);
});
