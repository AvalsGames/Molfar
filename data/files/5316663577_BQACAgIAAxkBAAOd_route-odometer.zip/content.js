// ── Route & Odometer — content script for app.tteld.com ──────────────────────
// Point format stored: "Display label||lat,lng"

const TAG = "data-ro-injected";
const DRIVER_TAG = "data-ro-driver-btn";
const DEFAULT_DRIVER_SHEET_URL =
  "https://docs.google.com/spreadsheets/d/1IzaVY4d5O8Zultua-7W41q3Xdngy2iW-3xgy67TKNvU/edit?gid=723311401#gid=723311401";
const DRIVER_ID_TAG = "data-ro-driver-id-btn";
const DRIVER_OPEN_TAG = "data-ro-driver-open-btn";
const DRIVER_LINKS_DB_KEY = "driverLinksDb";
let driverSheetUrlResolved = DEFAULT_DRIVER_SHEET_URL;
let driverLinksDbResolved = {};
// Prevent injecting multiple sets of buttons for the same driver on re-render.
const injectedDriverKeys = new Set(); // `${site}:${driverId}`
const BTN_STYLE = {
  base: { size: 16, radius: 4, opacity: 0.85, transitionMs: 150 },
  variants: {
    route: { bg: "#5b78ff" },
    map: { bg: "#1b9e77" },
    odo: { bg: "#f0a940" },
    driver: { bg: "#3b82f6" },
  },
};
const SITE_UI = {
  gleld: {
    odoLayout: { tdPaddingRight: 30, right: 4, top: "50%", zIndex: 2 },
  },
  tteld: {
    odoLayout: null,
  },
};
let roDebug = false;

function refreshDriverSheetUrlFromStorage() {
  chrome.storage.local.get(["driverSheetUrl"], d => {
    const v = d.driverSheetUrl;
    driverSheetUrlResolved =
      typeof v === "string" && v.trim() ? v.trim() : DEFAULT_DRIVER_SHEET_URL;
  });
}
refreshDriverSheetUrlFromStorage();

function refreshDriverLinksDbFromStorage() {
  chrome.storage.local.get([DRIVER_LINKS_DB_KEY], d => {
    const v = d[DRIVER_LINKS_DB_KEY];
    driverLinksDbResolved = v && typeof v === "object" ? v : {};
  });
}
refreshDriverLinksDbFromStorage();

// ── Inject page-context script (intercepts clipboard in page's JS world) ──────
(function injectPageScript() {
  const s = document.createElement("script");
  s.src = chrome.runtime.getURL("inject.js");
  (document.head || document.documentElement).appendChild(s);
  s.onload = () => s.remove();
})();

// ── Passive clipboard capture from inject.js ──────────────────────────────────
// Stores the last coords that the site wrote to clipboard, keyed by copy-div element
const coordsCache = new WeakMap(); // copy-div element → "lat,lng"
let lastActiveCopyDiv = null;      // which row's copy button was just clicked

window.addEventListener("__ro_clip__", (e) => {
  const text = e.detail || "";
  const coords = parseCoords(text);
  if (coords && lastActiveCopyDiv) {
    coordsCache.set(lastActiveCopyDiv, coords);
  }
});

// ── chrome.storage helpers ────────────────────────────────────────────────────
const getPoints = () =>
  new Promise(r => chrome.storage.local.get("routePoints", d => r(d.routePoints || [])));
const setPoints = pts =>
  new Promise(r => chrome.storage.local.set({ routePoints: pts }, r));

// ── Debug toggle (chrome.storage.local.roDebug) ───────────────────────────────
chrome.storage.local.get("roDebug", d => { roDebug = !!d.roDebug; });
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.roDebug) roDebug = !!changes.roDebug.newValue;
  if (changes.driverSheetUrl) {
    const v = changes.driverSheetUrl.newValue;
    driverSheetUrlResolved =
      typeof v === "string" && v.trim() ? v.trim() : DEFAULT_DRIVER_SHEET_URL;
  }
  if (changes.driverLinksDb) {
    const v = changes.driverLinksDb.newValue;
    driverLinksDbResolved = v && typeof v === "object" ? v : {};
  }
});
function dlog(...args) {
  if (roDebug) console.log("[RO]", ...args);
}

// ── Messenger links helpers ───────────────────────────────────────────────
function normalizeUrlToHttps(input) {
  const raw = (input || "").toString().trim();
  if (!raw) return "";
  if (!/^https?:\/\//i.test(raw)) return "https://" + raw.replace(/^\/+/, "");
  return raw.replace(/^http:\/\//i, "https://");
}

function normalizeNameKey(name) {
  return (name || "")
    .toString()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

function parseDriverIdFromText(text) {
  const m = (text || "").match(/Driver ID:\s*(\d+)/i);
  return m ? m[1] : null;
}

function parseIntFromText(text) {
  const s = (text || "").toString().trim();
  if (!s) return null;
  // Strip anything in parentheses first (e.g. "(+123)" or "(-45)" diff markers)
  const withoutParens = s.replace(/\([^)]*\)/g, "").trim();
  const m = withoutParens.match(/\d[\d\s,]*/);
  if (!m) return null;
  const n = parseInt(m[0].replace(/[\s,]/g, ""), 10);
  return Number.isFinite(n) ? n : null;
}

function parseStateFromLocationText(text) {
  const s = (text || "").toString().trim();
  const m = s.match(/,\s*([A-Z]{2})\b/);
  return m ? m[1] : null;
}

function getDriverCardContext(startEl) {
  let node = startEl;
  for (let i = 0; i < 8 && node; i++) {
    if (/Driver ID:\s*\d+/i.test(node.textContent || "")) return node;
    node = node.parentElement;
  }
  return null;
}

function findDriverIdElement(cardEl) {
  if (!cardEl) return null;
  const candidates = cardEl.querySelectorAll("span, div, p, a");
  for (const el of candidates) {
    if (/Driver ID:\s*\d+/i.test(el.textContent || "")) return el;
  }
  return null;
}

async function upsertDriverLink(site, driverId, url) {
  const normalized = normalizeUrlToHttps(url);
  if (!normalized) return false;

  const data = await new Promise(r =>
    chrome.storage.local.get([DRIVER_LINKS_DB_KEY], r)
  );
  const db = data[DRIVER_LINKS_DB_KEY] && typeof data[DRIVER_LINKS_DB_KEY] === "object"
    ? data[DRIVER_LINKS_DB_KEY]
    : {};
  db[site] = db[site] && typeof db[site] === "object" ? db[site] : {};
  db[site][driverId] = normalized;

  await new Promise(r => chrome.storage.local.set({ [DRIVER_LINKS_DB_KEY]: db }, r));
  driverLinksDbResolved = db; // keep local copy fresh
  return true;
}

async function upsertDriverLinkByName(siteKey, nameKey, url) {
  const normalized = normalizeUrlToHttps(url);
  if (!normalized || !nameKey) return false;

  const data = await new Promise(r =>
    chrome.storage.local.get([DRIVER_LINKS_DB_KEY], r)
  );
  const db = data[DRIVER_LINKS_DB_KEY] && typeof data[DRIVER_LINKS_DB_KEY] === "object"
    ? data[DRIVER_LINKS_DB_KEY]
    : {};
  db[siteKey] = db[siteKey] && typeof db[siteKey] === "object" ? db[siteKey] : {};
  db[siteKey][nameKey] = normalized;

  await new Promise(r => chrome.storage.local.set({ [DRIVER_LINKS_DB_KEY]: db }, r));
  driverLinksDbResolved = db;
  return true;
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styleEl = document.createElement("style");
styleEl.textContent = `
  @keyframes ro-in  { from { opacity:0; transform:translateY(6px) } to { opacity:1; transform:none } }
  @keyframes ro-out { from { opacity:1 } to { opacity:0 } }
  .ro-toast {
    position:fixed; bottom:20px; right:20px; z-index:2147483647;
    padding:8px 14px; border-radius:8px; font-size:13px;
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
    color:#fff; box-shadow:0 4px 16px rgba(0,0,0,.35);
    animation: ro-in .2s ease forwards; pointer-events:none;
  }
  .ro-map-overlay {
    position:fixed; inset:0; z-index:2147483640;
    background:rgba(0,0,0,.55);
    display:flex; align-items:center; justify-content:center;
  }
  .ro-map-box {
    background:#0e1330; border-radius:12px;
    box-shadow:0 8px 40px rgba(0,0,0,.7);
    width:580px; max-width:94vw; overflow:hidden;
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
  }
  .ro-map-header {
    display:flex; align-items:center; gap:8px; padding:10px 14px;
    background:#131942; border-bottom:1px solid rgba(91,120,255,0.2);
  }
  .ro-map-title { flex:1; min-width:0; }
  .ro-map-addr { font-size:13px; color:#e8eeff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .ro-map-coords { font-size:10px; color:#5b78ff; margin-top:1px; font-family:monospace; }
  .ro-map-close {
    background:none; border:none; cursor:pointer; color:#8898cc;
    font-size:18px; line-height:1; padding:2px 6px; border-radius:4px; flex-shrink:0;
    transition:color .12s, background .12s;
  }
  .ro-map-close:hover { color:#ff5b5b; background:rgba(255,91,91,0.1); }
  .ro-map-iframe { width:100%; height:380px; border:none; display:block; }
  .ro-map-footer {
    display:flex; align-items:center; justify-content:space-between;
    padding:8px 14px; background:#131942;
    border-top:1px solid rgba(91,120,255,0.2);
  }
  .ro-map-open-link {
    font-size:11px; color:#5b78ff; text-decoration:none;
    font-weight:700; letter-spacing:0.5px; text-transform:uppercase;
  }
  .ro-map-open-link:hover { color:#8aaeff; }
  .ro-map-hint { font-size:10px; color:#5a6899; }

  /* ── GLELD odometer alignment: keep value + button on one line ── */
  [data-ro-gleld-odo] {
    display:inline-block !important;
    margin-right:4px;
    vertical-align:middle;
  }
  [data-ro-gleld-odo] + button[title="Додати в калькулятор одометра"] {
    vertical-align:middle;
  }
`;
document.head.appendChild(styleEl);

// ── Toast ─────────────────────────────────────────────────────────────────────
function toast(msg, color = "#4caf50") {
  const el = document.createElement("div");
  el.className = "ro-toast";
  el.style.background = color;
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => {
    el.style.animation = "ro-out .3s ease forwards";
    setTimeout(() => el.remove(), 320);
  }, 2500);
}

// ── Coords parser — handles "lat, lng" / "lat,lng" / JSON ────────────────────
function parseCoords(text) {
  if (!text) return null;
  const s = text.trim();

  // "40.71916, -73.59234" or "40.71916,-73.59234"
  const m = s.match(/^(-?\d{1,3}\.\d+),\s*(-?\d{1,3}\.\d+)$/);
  if (m) return `${m[1]},${m[2]}`;

  // Embedded in longer string
  const em = s.match(/(-?\d{1,3}\.\d{4,}),\s*(-?\d{1,3}\.\d{4,})/);
  if (em) return `${em[1]},${em[2]}`;

  // JSON
  try {
    const obj = JSON.parse(s);
    const lat = obj.lat ?? obj.latitude;
    const lng = obj.lng ?? obj.lon ?? obj.longitude;
    if (lat !== undefined && lng !== undefined) return `${lat},${lng}`;
  } catch (_) {}

  return null;
}

// ── Trigger the site's copy button and wait for __ro_clip__ event ─────────────
function triggerAndCapture(copyDiv) {
  return new Promise(resolve => {
    lastActiveCopyDiv = copyDiv;

    // One-shot listener for the clip event from inject.js
    function onClip(e) {
      const coords = parseCoords(e.detail || "");
      if (coords) {
        window.removeEventListener("__ro_clip__", onClip);
        clearTimeout(timer);
        resolve(coords);
      }
    }
    window.addEventListener("__ro_clip__", onClip);

    // Fallback: if no event within 1.5 s, check cache and give up
    const timer = setTimeout(() => {
      window.removeEventListener("__ro_clip__", onClip);
      resolve(coordsCache.get(copyDiv) || null);
    }, 1500);

    // Click the inner Vue button
    const innerBtn = copyDiv.querySelector('[role="button"]') || copyDiv;
    innerBtn.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
  });
}

// ── Get coords for a row — uses cache first, then triggers copy ───────────────
async function getCoords(copyDiv) {
  // If we already captured coords for this row, use them
  const cached = coordsCache.get(copyDiv);
  if (cached) return cached;

  // Otherwise trigger the site's copy button
  return triggerAndCapture(copyDiv);
}

// ── Map popup ─────────────────────────────────────────────────────────────────
function showMapPopup(label, coords) {
  document.querySelector(".ro-map-overlay")?.remove();

  const embedUrl = coords
    ? `https://maps.google.com/maps?q=${encodeURIComponent(coords)}&output=embed&hl=en&t=k&z=14`
    : `https://maps.google.com/maps?q=${encodeURIComponent(label)}&output=embed&hl=en&t=k`;
  const mapsUrl = coords
    ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(coords)}`
    : `https://www.google.com/maps/search/${encodeURIComponent(label)}?hl=en`;

  const overlay = document.createElement("div");
  overlay.className = "ro-map-overlay";
  overlay.innerHTML = `
    <div class="ro-map-box">
      <div class="ro-map-header">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="#5b78ff" style="flex-shrink:0">
          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
        </svg>
        <div class="ro-map-title">
          <div class="ro-map-addr" title="${label}">${label}</div>
          ${coords ? `<div class="ro-map-coords">${coords}</div>` : ""}
        </div>
        <button class="ro-map-close" title="Закрити">✕</button>
      </div>
      <iframe class="ro-map-iframe" src="${embedUrl}"
        allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade">
      </iframe>
      <div class="ro-map-footer">
        <a class="ro-map-open-link" href="${mapsUrl}" target="_blank" rel="noopener">
          ↗ Відкрити в Google Maps
        </a>
        <span class="ro-map-hint">Esc або клік поза картою — закрити</span>
      </div>
    </div>
  `;
  overlay.querySelector(".ro-map-close").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", e => { if (e.target === overlay) overlay.remove(); });
  document.addEventListener("keydown", function esc(e) {
    if (e.key === "Escape") { overlay.remove(); document.removeEventListener("keydown", esc); }
  });
  document.body.appendChild(overlay);
}

// ── Button factory ────────────────────────────────────────────────────────────
function makeBtn(title, svgPath, bgColor, onClick, opts = {}) {
  const size = opts.size ?? BTN_STYLE.base.size;
  const radius = opts.radius ?? BTN_STYLE.base.radius;
  const opacity = opts.opacity ?? BTN_STYLE.base.opacity;
  const btn = document.createElement("button");
  btn.title = title;
  btn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="white">${svgPath}</svg>`;
  btn.style.cssText = `
    display:inline-flex;align-items:center;justify-content:center;
    width:${size}px;height:${size}px;border-radius:${radius}px;border:none;
    background:${bgColor};cursor:pointer;flex-shrink:0;
    margin-left:3px;padding:0;vertical-align:middle;
    opacity:${opacity};transition:opacity .${BTN_STYLE.base.transitionMs}ms;
  `;
  btn.addEventListener("mouseenter", () => { btn.style.opacity="1"; });
  btn.addEventListener("mouseleave", () => { btn.style.opacity=String(opacity); });
  btn.addEventListener("click", e => { e.stopPropagation(); e.preventDefault(); onClick(); });
  return btn;
}

// ── Clipboard helper ───────────────────────────────────────────────────────────
async function copyText(text) {
  const value = (text || "").trim();
  if (!value) return false;
  try {
    await navigator.clipboard.writeText(value);
    return true;
  } catch (_) {
    try {
      const ta = document.createElement("textarea");
      ta.value = value;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.left = "-9999px";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      return !!ok;
    } catch (__){
      return false;
    }
  }
}

// ── Driver name button ────────────────────────────────────────────────────────
function getDriverName(el) {
  if (!el) return "";
  // Support <input value="..."> (Forza) as well as text nodes (TT/GLELD).
  const val = (el.tagName === "INPUT" || el.tagName === "TEXTAREA") ? el.value : "";
  const txt = (val || el.getAttribute("title") || el.textContent || "").replace(/\s+/g, " ").trim();
  return txt;
}

function injectDriverBtn(nameEl) {
  if (!nameEl || nameEl.hasAttribute(DRIVER_TAG)) return;

  const driverName = getDriverName(nameEl);
  if (!driverName || driverName.length < 3) return;
  // Avoid injecting on fields like phone/ids: driver name should contain letters.
  if (!/[A-Za-zА-Яа-яЁёЇіЄєҐґ]/.test(driverName)) return;

  const card = getDriverCardContext(nameEl);
  const driverId = parseDriverIdFromText(card ? card.textContent : "");
  if (!driverId) return;

  const site = IS_GLELD ? "gleld" : "tteld";
  const driverKey = `${site}:${driverId}`;
  if (injectedDriverKeys.has(driverKey)) return;

  nameEl.setAttribute(DRIVER_TAG, "1");

  // Keep name + button on one line where possible.
  nameEl.style.display = nameEl.style.display || "inline-block";
  nameEl.style.verticalAlign = "middle";

  const btn = makeBtn(
    "Копіювати ім'я водія + відкрити таблицю",
    `<path d="M16 1H4c-1.1 0-2 .9-2 2v12h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>`,
    BTN_STYLE.variants.driver.bg,
    async () => {
      const freshName = getDriverName(nameEl) || driverName;
      const copied = await copyText(freshName);
      window.open(driverSheetUrlResolved, "_blank", "noopener");
      toast(copied ? `✓ Скопійовано: ${freshName}` : `Відкрито таблицю`, copied ? "#3b82f6" : "#f0a940");
    }
  );

  nameEl.after(btn);

  // Inject ID link controls next to the name-copy button (for consistent layout).
  if (card) {
    const ok = injectDriverIdEditorBtn(card, site, driverId, btn);
    if (ok) injectedDriverKeys.add(driverKey);
  }
}

function injectDriverIdEditorBtn(cardEl, site, driverId, nameCopyBtnEl) {
  if (!cardEl) return false;

  const driverIdEl = findDriverIdElement(cardEl);
  const liveDriverId = driverId || parseDriverIdFromText(driverIdEl ? driverIdEl.textContent : cardEl.textContent);
  if (!liveDriverId) return false;
  if (!driverIdEl) return false;

  const hasEdit = !!cardEl.querySelector(`[${DRIVER_ID_TAG}="1"]`);
  const hasOpen = !!cardEl.querySelector(`[${DRIVER_OPEN_TAG}="1"]`);
  if (hasEdit && hasOpen) return true;

  // Create a small editor button next to the element that shows "Driver ID: NNN".
  let insertedAny = false;
  let editBtn = null;
  let openBtn = null;

  if (!hasEdit) {
    editBtn = makeBtn(
      "Встановити/змінити посилання для цього Driver ID",
      `<path d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/>`,
      BTN_STYLE.variants.driver.bg,
      async () => {
        const current =
          driverLinksDbResolved &&
          driverLinksDbResolved[site] &&
          driverLinksDbResolved[site][liveDriverId];

        const input = window.prompt(
          `Введіть URL для Driver ID ${liveDriverId} (наприклад: https://t.me/username)\nПоточне: ${current || "(порожнє)"}`,
          current || ""
        );
        if (input === null) return;
        const ok = await upsertDriverLink(site, liveDriverId, input);
        if (ok) toast("✓ Посилання збережено.", "#3cd69e");
        else toast("Не вдалося зберегти посилання. Перевір URL.", "#f0a940");
      }
    );
    editBtn.setAttribute(DRIVER_ID_TAG, "1");
    insertedAny = true;
  }

  if (!hasOpen) {
    openBtn = makeBtn(
      "Відкрити посилання для цього Driver ID",
      `<path d="M14 3h7v7h-2V6.41l-9.29 9.3-1.42-1.42 9.3-9.29H14V3zM5 5h6v2H7v10h10v-4h2v6H5V5z"/>`,
      BTN_STYLE.variants.driver.bg,
      () => {
        const url =
          driverLinksDbResolved &&
          driverLinksDbResolved[site] &&
          driverLinksDbResolved[site][liveDriverId];
        if (!url) {
          toast("Посилання не задано. Натисніть 'додати/змінити' біля ID.", "#f0a940");
          return;
        }
        window.open(url, "_blank", "noopener");
      }
    );
    openBtn.setAttribute(DRIVER_OPEN_TAG, "1");
    insertedAny = true;
  }

  // Insert right after the name-copy button (if available) to avoid layout shifts.
  if (nameCopyBtnEl && nameCopyBtnEl.parentElement) {
    const parent = nameCopyBtnEl.parentElement;
    const ref = nameCopyBtnEl.nextSibling;
    if (editBtn && openBtn) {
      parent.insertBefore(editBtn, ref);
      parent.insertBefore(openBtn, ref);
    } else if (editBtn) {
      parent.insertBefore(editBtn, ref);
    } else if (openBtn) {
      parent.insertBefore(openBtn, ref);
    }
  } else {
    // Fallback: insert relative to Driver ID element.
    if (editBtn && openBtn) driverIdEl.after(editBtn, openBtn);
    else if (editBtn) driverIdEl.after(editBtn);
    else if (openBtn) {
      const existingEdit = cardEl.querySelector(`[${DRIVER_ID_TAG}="1"]`);
      (existingEdit || driverIdEl).after(openBtn);
    }
  }

  return insertedAny;
}

// ── Odometer button ───────────────────────────────────────────────────────────
const ODO_TAG = "data-ro-odo";

// Returns the lowercase text of the <th> header for the column that contains el
function getColHeader(el) {
  let node = el;
  while (node && node.tagName !== "TD") node = node.parentElement;
  if (!node) return "";
  const tr = node.parentElement;
  if (!tr) return "";
  const colIdx = Array.from(tr.children).indexOf(node);

  let table = node;
  while (table && table.tagName !== "TABLE") table = table.parentElement;
  if (!table) return "";

  const thead = table.querySelector("thead");
  if (!thead) return "";
  const headerRow = thead.querySelector("tr");
  if (!headerRow) return "";

  const th = headerRow.children[colIdx];
  return th ? th.textContent.trim().toLowerCase() : "";
}

// ── Extract 2-letter US state code from the Location cell of the same row ─────
function getStateFromRow(el) {
  // Walk up to the <tr>
  let node = el;
  while (node && node.tagName !== "TR") node = node.parentElement;
  if (!node) return null;

  // Scan all value-text elements in the row for "…, XX" pattern (address ending)
  const cells = node.querySelectorAll(".edit-single__value-text, .edit-single_value-text");
  for (const cell of cells) {
    const txt = cell.textContent.trim();
    const m = txt.match(/,\s*([A-Z]{2})\s*(?:\s|$)/);
    if (m) return m[1];
  }
  return null;
}

function injectOdo(el) {
  if (el.hasAttribute(ODO_TAG)) return;

  const raw = el.textContent.trim();
  // Strip parenthesised diff markers like "(+123)" or "(-45)" before parsing
  const rawNoParen = raw.replace(/\([^)]*\)/g, "").trim();
  // Must be purely numeric (digits, spaces, commas) — no letters like in addresses
  const cleaned = rawNoParen.replace(/[\s,]/g, "");
  if (!/^\d+$/.test(cleaned)) return;
  const val = parseInt(cleaned, 10);
  if (val < 100) return; // skip tiny numbers; real odometers are much larger

  // Check column header — skip engine hours and any non-odometer numeric columns
  const header = getColHeader(el);
  const isEngHrs = /eng|hrs|hour/i.test(header);
  const isOdo    = /odo/i.test(header);
  // If header is known and it's NOT odometer → skip
  if (header && !isOdo) return;
  // Extra safety: if detected as engine hours regardless → skip
  if (isEngHrs) return;

  el.setAttribute(ODO_TAG, "1");

  // Clock/timer icon — same as popup's odometer section
  const odoBtn = makeBtn(
    "Додати в калькулятор одометра",
    `<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z"/>`,
    BTN_STYLE.variants.odo.bg,
    async () => {
      const saved = (await new Promise(r => chrome.storage.local.get("odoValues", r))).odoValues || {};
      const state = getStateFromRow(el);
      let target;
      if (!saved.od1) {
        target = "OD 1";
        saved.od1 = String(val);
        if (state) saved.s1 = state;
      } else if (!saved.od2) {
        target = "OD 2";
        saved.od2 = String(val);
        if (state) saved.s2 = state;
      } else {
        // Both filled — start fresh cycle
        target = "OD 1";
        saved.od1 = String(val); saved.od2 = "";
        saved.s1 = state || (saved.s1 || ""); saved.s2 = "";
      }
      await new Promise(r => chrome.storage.local.set({ odoValues: saved }, r));
      const stateHint = state ? ` · ${state}` : "";
      toast(`✓ ${target}: ${val.toLocaleString()} mi${stateHint}`, "#f0a940");
    }
  );

  // Insert right after the value element
  el.after(odoBtn);
}

// ── Inject buttons next to one copy-location element ─────────────────────────
function inject(copyDiv) {
  if (copyDiv.hasAttribute(TAG)) return;
  copyDiv.setAttribute(TAG, "1");

  const parent = copyDiv.parentElement;
  const addrEl = parent && (
    parent.querySelector(".edit-single__value-text") ||
    parent.querySelector(".edit-single_value-text")
  );
  const label = addrEl ? addrEl.textContent.trim() : "";
  if (!label || label.length < 5) return;

  // Also passively capture coords when user clicks the ORIGINAL copy button
  const innerBtn = copyDiv.querySelector('[role="button"]') || copyDiv;
  innerBtn.addEventListener("click", () => { lastActiveCopyDiv = copyDiv; }, true);

  // ── "+ Route" button ───────────────────────────────────────────────────────
  const addBtn = makeBtn(
    "Додати до маршруту",
    `<path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>`,
    BTN_STYLE.variants.route.bg,
    async () => {
      const pts = await getPoints();
      if (pts.some(p => p.split("||")[0] === label)) {
        toast("Вже є в маршруті", "#f0a940"); return;
      }
      const coords = await getCoords(copyDiv);
      const entry  = coords ? `${label}||${coords}` : label;
      pts.push(entry);
      await setPoints(pts);
      toast(coords ? `✓ Додано: ${label}` : `✓ Додано (без координат): ${label}`);
    }
  );

  // ── Map button ─────────────────────────────────────────────────────────────
  const mapBtn = makeBtn(
    "Показати на карті",
    `<path d="M20.5 3l-.16.03L15 5.1 9 3 3.36 4.9c-.21.07-.36.25-.36.48V20.5c0 .28.22.5.5.5l.16-.03L9 18.9l6 2.1 5.64-1.9c.21-.07.36-.25.36-.48V3.5c0-.28-.22-.5-.5-.5zM15 19l-6-2.11V5l6 2.11V19z"/>`,
    BTN_STYLE.variants.map.bg,
    async () => {
      showMapPopup(label, coordsCache.get(copyDiv) || null);
      const coords = await getCoords(copyDiv);
      if (coords) showMapPopup(label, coords);
    }
  );

  copyDiv.after(addBtn, mapBtn);
}

// ══════════════════════════════════════════════════════════════════════════════
// ── GLELD.COM — odometer-only injection ──────────────────────────────────────
// ══════════════════════════════════════════════════════════════════════════════
const GLELD_TAG = "data-ro-gleld-odo";

// Extract state code from the copy-text address span in the same <tr>
function getGleldState(el) {
  let node = el;
  while (node && node.tagName !== "TR") node = node.parentElement;
  if (!node) return null;
  // A row contains several .copy-text spans (time, duration, location, etc.).
  // Find the one that actually contains an address ending with ", XX".
  const cells = node.querySelectorAll("span.copy-text");
  for (const cell of cells) {
    const txt = (cell.getAttribute("title") || cell.textContent || "").trim();
    const m = txt.match(/,\s*([A-Z]{2})\s*(?:\s|$)/);
    if (m) return m[1];
  }
  return null;
}

// Shared odo-save logic (target = "OD 1" / "OD 2")
async function saveOdo(val, state) {
  const saved = (await new Promise(r => chrome.storage.local.get("odoValues", r))).odoValues || {};
  let target;
  if (!saved.od1) {
    target = "OD 1"; saved.od1 = String(val);
    if (state) saved.s1 = state;
  } else if (!saved.od2) {
    target = "OD 2"; saved.od2 = String(val);
    if (state) saved.s2 = state;
  } else {
    target = "OD 1"; saved.od1 = String(val); saved.od2 = "";
    saved.s1 = state || (saved.s1 || ""); saved.s2 = "";
  }
  await new Promise(r => chrome.storage.local.set({ odoValues: saved }, r));
  const hint = state ? ` · ${state}` : "";
  toast(`✓ ${target}: ${val.toLocaleString()} mi${hint}`, "#f0a940");
}

function injectGleldOdo(el) {
  if (el.hasAttribute(GLELD_TAG)) return;

  const raw = el.textContent.trim();
  // Strip parenthesised diff markers like "(+123)" or "(-45)" before parsing
  const rawNoParen = raw.replace(/\([^)]*\)/g, "").trim();
  const cleaned = rawNoParen.replace(/[\s,]/g, "");
  if (!/^\d+$/.test(cleaned)) return;
  const val = parseInt(cleaned, 10);
  if (val < 100) return;

  // Use column header to distinguish Odometer from other numeric columns
  const header = getColHeader(el);
  if (!header) return;
  if (/eng|hrs|hour/i.test(header)) return;      // skip Engine Hours
  if (!/odo/i.test(header)) return;              // require Odometer column
  dlog("inject gleld odo", { val, header });

  el.setAttribute(GLELD_TAG, "1");

  const btn = makeBtn(
    "Додати в калькулятор одометра",
    `<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z"/>`,
    BTN_STYLE.variants.odo.bg,
    () => saveOdo(val, getGleldState(el))
  );
  // Prefer to append into the containing <td> so that the truncated
  // span with max-width does not hide the button (only the text).
  let td = el;
  while (td && td.tagName !== "TD") td = td.parentElement;
  if (td) {
    const layout = SITE_UI.gleld.odoLayout;
    td.style.position = "relative";
    // Reserve space so button does not overlap odometer text.
    td.style.paddingRight = `${layout.tdPaddingRight}px`;
    btn.style.position = "absolute";
    btn.style.right = `${layout.right}px`;
    btn.style.top = layout.top;
    btn.style.transform = "translateY(-50%)";
    btn.style.marginLeft = "0";
    btn.style.zIndex = String(layout.zIndex);
    // Override hover animation from makeBtn: only fix vertical transform.
    btn.onmouseenter = () => { btn.style.opacity = "1"; btn.style.transform = "translateY(-50%)"; };
    btn.onmouseleave = () => { btn.style.opacity = String(BTN_STYLE.base.opacity); btn.style.transform = "translateY(-50%)"; };
    td.appendChild(btn);
  } else {
    el.after(btn);
  }
}

function scanGleld() {
  // gleld.com uses slightly different DOM wrappers in different rows.
  // So scan all editable dialog-trigger spans and let injectGleldOdo
  // decide based on numeric content + headers.
  document.querySelectorAll('span[aria-haspopup="dialog"]')
    .forEach(el => injectGleldOdo(el));
}

// ── Scan ─────────────────────────────────────────────────────────────────────
const IS_GLELD = location.hostname.includes("gleld.com");
const IS_FORZA = location.hostname.includes("forza-wcp.online");

function scan() {
  dlog("scan start", { host: location.hostname });
  if (IS_FORZA) {
    scanForza();
    return;
  }
  if (IS_GLELD) {
    scanGleld();
  } else {
    document.querySelectorAll(".copy-location").forEach(el => inject(el));
    document.querySelectorAll(".edit-single__value-text, .edit-single_value-text")
      .forEach(el => injectOdo(el));
  }

  // Driver name button: try multiple DOM variants for both sites.
  document.querySelectorAll('[aria-label="Copy Driver Name"], .log-driver__name, .copy-text')
    .forEach(el => injectDriverBtn(el));
}

// ══════════════════════════════════════════════════════════════════════════════
// ── FORZA-WCP.ONLINE (Angular Material) ───────────────────────────────────────
// ══════════════════════════════════════════════════════════════════════════════
const FORZA_TAG = "data-ro-forza";

function scanForza() {
  // 1) Driver name: the visible selected value is often an <input readonly ... value="Name">
  document.querySelectorAll("mat-select-trigger input[readonly]")
    .forEach(el => injectForzaDriverName(el));

  // 2) Route: keep button inside the context menu (works reliably for coordinates).
  document.querySelectorAll('button[data-testid="copy-coordinates"]')
    .forEach(btn => injectForzaRoute(btn));

  // 3) Odometer: keep button next to cell value.
  injectForzaRowButtons();
}

function injectForzaDriverName(inputEl) {
  if (!inputEl || inputEl.hasAttribute(FORZA_TAG)) return;
  const name = getDriverName(inputEl);
  if (!name || name.length < 3) return;
  inputEl.setAttribute(FORZA_TAG, "1");
  // Reuse driver button (copy name + open sheet). No ID features for Forza.
  const btn = makeBtn(
    "Копіювати ім'я водія + відкрити таблицю",
    `<path d="M16 1H4c-1.1 0-2 .9-2 2v12h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>`,
    BTN_STYLE.variants.driver.bg,
    async () => {
      const freshName = getDriverName(inputEl) || name;
      const copied = await copyText(freshName);
      window.open(driverSheetUrlResolved, "_blank", "noopener");
      toast(copied ? `✓ Скопійовано: ${freshName}` : `Відкрито таблицю`, copied ? "#3b82f6" : "#f0a940");
    }
  );
  // Prefer placing the button in the same flex row as the visible name.
  // The input itself is often inside a trigger; inserting after it can wrap.
  const trigger = inputEl.closest("mat-select-trigger") || inputEl.parentElement;
  const row = trigger && (trigger.closest(".mat-mdc-select-trigger") || trigger.parentElement);
  const anchor = row || trigger || inputEl;
  if (anchor && anchor.parentElement) {
    const parent = anchor.parentElement;
    parent.style.display = parent.style.display || "flex";
    parent.style.alignItems = parent.style.alignItems || "center";
    parent.style.gap = parent.style.gap || "6px";

    const nameKey = normalizeNameKey(name);
    const editBtn = makeBtn(
      "Додати/змінити посилання (за ім'ям)",
      `<path d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/>`,
      BTN_STYLE.variants.driver.bg,
      async () => {
        const latestName = getDriverName(inputEl) || name;
        const latestKey = normalizeNameKey(latestName);
        const current =
          driverLinksDbResolved &&
          driverLinksDbResolved.forza_name &&
          driverLinksDbResolved.forza_name[latestKey];

        const input = window.prompt(
          `Введіть URL для водія "${latestName}"\nПоточне: ${current || "(порожнє)"}`,
          current || ""
        );
        if (input === null) return;
        const ok = await upsertDriverLinkByName("forza_name", latestKey, input);
        if (ok) toast("✓ Посилання збережено.", "#3cd69e");
        else toast("Не вдалося зберегти посилання. Перевір URL.", "#f0a940");
      }
    );

    const openBtn = makeBtn(
      "Відкрити посилання (за ім'ям)",
      `<path d="M14 3h7v7h-2V6.41l-9.29 9.3-1.42-1.42 9.3-9.29H14V3zM5 5h6v2H7v10h10v-4h2v6H5V5z"/>`,
      BTN_STYLE.variants.driver.bg,
      () => {
        const latestName = getDriverName(inputEl) || name;
        const latestKey = normalizeNameKey(latestName);
        const url =
          driverLinksDbResolved &&
          driverLinksDbResolved.forza_name &&
          driverLinksDbResolved.forza_name[latestKey];
        if (!url) {
          toast("Посилання для цього імені не задано.", "#f0a940");
          return;
        }
        window.open(url, "_blank", "noopener");
      }
    );

    // Put all 3 buttons in a separate group to the right of the whole field
    // (outside select input), so driver name stays fully visible.
    const btnGroup = document.createElement("span");
    btnGroup.style.cssText = `
      display: inline-flex;
      align-items: center;
      gap: 4px;
      margin-left: 6px;
      flex-shrink: 0;
    `;
    btnGroup.appendChild(btn);
    btnGroup.appendChild(editBtn);
    btnGroup.appendChild(openBtn);

    // Prefer placing group right after full mat-select field wrapper
    // so it appears to the right of the clear (x) icon.
    const fieldWrap =
      inputEl.closest(".mat-mdc-form-field") ||
      inputEl.closest("mat-form-field") ||
      inputEl.closest("mat-select");

    if (fieldWrap && fieldWrap.parentElement) {
      const host = fieldWrap.parentElement;
      host.style.display = "flex";
      host.style.alignItems = "center";
      host.style.gap = "6px";
      host.style.flexWrap = "nowrap";
      fieldWrap.style.flex = "1 1 auto";
      fieldWrap.style.minWidth = "0";
      host.appendChild(btnGroup);
    } else {
      parent.appendChild(btnGroup);
    }
  } else {
    inputEl.after(btn);
  }
}

function injectForzaRoute(copyBtn) {
  const tag = "data-ro-forza-route-menu";
  if (!copyBtn || copyBtn.hasAttribute(tag)) return;
  copyBtn.setAttribute(tag, "1");

  // Create a full-width menu item (not a tiny square icon button).
  const addBtn = document.createElement("button");
  addBtn.type = "button";
  addBtn.title = "Додати координати до маршруту";
  addBtn.style.cssText = `
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    gap: 10px;
    padding: 0 16px;
    height: 40px;
    border: none;
    background: transparent;
    color: inherit;
    cursor: pointer;
    text-align: left;
    font: inherit;
    opacity: .92;
  `;
  addBtn.addEventListener("mouseenter", () => { addBtn.style.opacity = "1"; addBtn.style.background = "rgba(91,120,255,0.08)"; });
  addBtn.addEventListener("mouseleave", () => { addBtn.style.opacity = ".92"; addBtn.style.background = "transparent"; });

  const icon = document.createElement("span");
  icon.style.cssText = `
    width: 18px;
    height: 18px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex: 0 0 18px;
    border-radius: 4px;
    background: rgba(91,120,255,0.12);
  `;
  icon.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="#5b78ff" aria-hidden="true">
    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
  </svg>`;

  const textEl = document.createElement("span");
  textEl.textContent = "В маршрут";
  textEl.style.cssText = "font-size: 13px; font-weight: 600; letter-spacing: .2px;";

  addBtn.append(icon, textEl);
  addBtn.addEventListener("click", async (e) => {
    e.stopPropagation();
    e.preventDefault();
    const text = await triggerAndCapture(copyBtn);
    const coords = parseCoords(text || "");
    if (!coords) {
      toast("Не вдалося зчитати координати.", "#f0a940");
      return;
    }
    const label = `Coords ${coords}`;
    const entry = `${label}||${coords}`;
    const pts = await getPoints();
    pts.push(entry);
    await setPoints(pts);
    toast(`✓ Додано координати: ${coords}`, "#5b78ff");
  });

  // Insert right under "Copy Coordinates" menu item.
  copyBtn.after(addBtn);
}

function injectForzaRowButtons() {
  // Find tables and map header indices for Location/Odometer.
  const tables = document.querySelectorAll("table");
  tables.forEach(table => {
    const headRow = table.querySelector("thead tr");
    if (!headRow) return;
    const headers = Array.from(headRow.children).map(th => (th.textContent || "").trim().toLowerCase());
    const locIdx = headers.findIndex(h => h === "location" || h.includes("location"));
    const odoIdx = headers.findIndex(h => h === "odometer" || h.includes("odometer"));
    if (locIdx < 0 && odoIdx < 0) return;

    const rows = table.querySelectorAll("tbody tr");
    rows.forEach(tr => {
      if (tr.hasAttribute("data-ro-forza-row")) return;

      const tds = Array.from(tr.children).filter(el => el && el.tagName === "TD");
      if (!tds.length) return;

      // Find menu trigger in the row (to access copy actions reliably).
      const menuTrigger =
        tr.querySelector('[mat-menu-trigger-for], [matMenuTriggerFor], button[aria-haspopup="menu"], button[aria-haspopup="dialog"]') ||
        null;

      const locCell = (locIdx >= 0 && tds[locIdx]) ? tds[locIdx] : null;

      // Inject odo button near Odometer cell.
      if (odoIdx >= 0 && tds[odoIdx]) {
        injectForzaCellOdo(tds[odoIdx], menuTrigger, locCell);
      }

      tr.setAttribute("data-ro-forza-row", "1");
    });
  });
}

async function forzaOpenMenuAndGetCopyButton(rowEl, menuTrigger, testIds) {
  if (!rowEl) return null;
  // Try to open the row menu so copy buttons exist in DOM.
  if (menuTrigger) {
    try {
      menuTrigger.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
    } catch (_) {}
  }
  // Prefer the most recently opened Angular CDK overlay.
  const overlayPanes = Array.from(document.querySelectorAll(".cdk-overlay-pane"));
  const lastPane = overlayPanes.length ? overlayPanes[overlayPanes.length - 1] : null;

  const pickEnabled = (els) =>
    Array.from(els).reverse().find(b => !b.disabled && b.getAttribute("aria-disabled") !== "true") || null;

  for (const id of testIds) {
    if (lastPane) {
      const inPane = pickEnabled(lastPane.querySelectorAll(`button[data-testid="${id}"]`));
      if (inPane) return inPane;
    }
    const global = pickEnabled(document.querySelectorAll(`button[data-testid="${id}"]`));
    if (global) return global;
  }
  return null;
}

async function readClipboardTextWithRetry(tries = 3, delayMs = 120) {
  for (let i = 0; i < tries; i++) {
    try {
      const t = await navigator.clipboard.readText();
      if (t && t.trim()) return t;
    } catch (_) {}
    await new Promise(r => setTimeout(r, delayMs));
  }
  return "";
}

function injectForzaCellRoute(cellEl, menuTrigger) {
  const tag = "data-ro-forza-route";
  if (!cellEl || cellEl.hasAttribute(tag)) return;
  cellEl.setAttribute(tag, "1");

  const btn = makeBtn(
    "Додати локацію до маршруту",
    `<path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>`,
    BTN_STYLE.variants.route.bg,
    async () => {
      const row = cellEl.closest("tr") || cellEl.parentElement;
      // Prefer coordinates first so Google Maps route works reliably.
      const copyBtn = await forzaOpenMenuAndGetCopyButton(row, menuTrigger, ["copy-coordinates", "copy-location"]);
      let text = "";
      if (copyBtn) {
        // Forza sometimes writes to clipboard without using navigator.clipboard.writeText
        // in a way we can intercept, so we read clipboard directly after click.
        try {
          copyBtn.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
        } catch (_) {}
        text = await readClipboardTextWithRetry(4, 150);
        if (!text) text = await triggerAndCapture(copyBtn);
      }

      const coords = parseCoords(text || "");
      if (coords) {
        const label = `Coords ${coords}`;
        const entry = `${label}||${coords}`;
        const pts = await getPoints();
        pts.push(entry);
        await setPoints(pts);
        toast(`✓ Додано координати: ${coords}`, "#5b78ff");
        return;
      }
      // Fallback: treat as plain address string (clipboard if present, else cell text)
      const addr = (text || "").trim() || (cellEl.textContent || "").trim();
      if (!addr) {
        toast("Не вдалося зчитати локацію.", "#f0a940");
        return;
      }
      const pts = await getPoints();
      pts.push(addr);
      await setPoints(pts);
      toast(`✓ Додано: ${addr}`, "#5b78ff");
    }
  );

  // Overlay on the right inside the cell (no row wrap).
  cellEl.style.position = cellEl.style.position || "relative";
  cellEl.style.paddingRight = cellEl.style.paddingRight || "28px";
  btn.style.position = "absolute";
  btn.style.right = "4px";
  btn.style.top = "50%";
  btn.style.transform = "translateY(-50%)";
  btn.style.marginLeft = "0";
  btn.style.zIndex = "2";
  cellEl.appendChild(btn);
}

function injectForzaCellOdo(cellEl, menuTrigger) {
  const tag = "data-ro-forza-odo-cell";
  if (!cellEl || cellEl.hasAttribute(tag)) return;
  cellEl.setAttribute(tag, "1");

  const btn = makeBtn(
    "Додати одометр в калькулятор",
    `<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z"/>`,
    BTN_STYLE.variants.odo.bg,
    async () => {
      const row = cellEl.closest("tr") || cellEl.parentElement;
      const copyBtn = await forzaOpenMenuAndGetCopyButton(row, menuTrigger, ["copy-odometer"]);
      const text = copyBtn ? await triggerAndCapture(copyBtn) : "";
      const val = parseIntFromText(text || "") || parseIntFromText(cellEl.textContent || "");
      if (!val) {
        toast("Не вдалося зчитати одометр.", "#f0a940");
        return;
      }
      await saveOdo(val, null);
    }
  );

  // Overlay on the right inside the cell (no row wrap).
  cellEl.style.position = cellEl.style.position || "relative";
  cellEl.style.paddingRight = cellEl.style.paddingRight || "28px";
  btn.style.position = "absolute";
  btn.style.right = "4px";
  btn.style.top = "50%";
  btn.style.transform = "translateY(-50%)";
  btn.style.marginLeft = "0";
  btn.style.zIndex = "2";
  cellEl.appendChild(btn);
}

function injectForzaCellOdo(cellEl, menuTrigger, locCellEl) {
  const tag = "data-ro-forza-odo-cell";
  if (!cellEl || cellEl.hasAttribute(tag)) return;
  cellEl.setAttribute(tag, "1");

  const btn = makeBtn(
    "Додати одометр в калькулятор",
    `<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z"/>`,
    BTN_STYLE.variants.odo.bg,
    async () => {
      const row = cellEl.closest("tr") || cellEl.parentElement;
      const copyBtn = await forzaOpenMenuAndGetCopyButton(row, menuTrigger, ["copy-odometer"]);
      const text = copyBtn ? await triggerAndCapture(copyBtn) : "";
      const val = parseIntFromText(text || "") || parseIntFromText(cellEl.textContent || "");
      if (!val) {
        toast("Не вдалося зчитати одометр.", "#f0a940");
        return;
      }
      const state = parseStateFromLocationText((locCellEl && locCellEl.textContent) || "");
      await saveOdo(val, state);
    }
  );

  // Overlay on the right inside the cell (no row wrap).
  cellEl.style.position = cellEl.style.position || "relative";
  cellEl.style.paddingRight = cellEl.style.paddingRight || "28px";
  btn.style.position = "absolute";
  btn.style.right = "4px";
  btn.style.top = "50%";
  btn.style.transform = "translateY(-50%)";
  btn.style.marginLeft = "0";
  btn.style.zIndex = "2";
  cellEl.appendChild(btn);
}

let pending = false;
const observer = new MutationObserver(() => {
  if (pending) return;
  pending = true;
  requestAnimationFrame(() => { scan(); pending = false; });
});
observer.observe(document.body, { childList: true, subtree: true });

scan();
[300, 800, 1500, 3000, 6000].forEach(ms => setTimeout(scan, ms));
