// Runs in PAGE context — intercepts clipboard writes and broadcasts them
(function () {
  // Intercept navigator.clipboard.writeText
  const origWriteText = navigator.clipboard.writeText.bind(navigator.clipboard);
  navigator.clipboard.writeText = function (text) {
    window.dispatchEvent(new CustomEvent("__ro_clip__", { detail: text }));
    return origWriteText(text);
  };

  // Also intercept document.execCommand('copy') as fallback
  const origExecCmd = document.execCommand.bind(document);
  document.execCommand = function (cmd, ...args) {
    const result = origExecCmd(cmd, ...args);
    if (cmd === "copy") {
      const sel = window.getSelection();
      const text = sel ? sel.toString() : "";
      if (text) window.dispatchEvent(new CustomEvent("__ro_clip__", { detail: text }));
    }
    return result;
  };
})();
